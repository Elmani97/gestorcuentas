import sys
import types
if 'wsgiref' not in sys.modules:
    sys.modules['wsgiref'] = types.ModuleType('wsgiref')
    sys.modules['wsgiref.simple_server'] = types.ModuleType('simple_server')

import flet as ft
import datetime, calendar, urllib.parse, webbrowser, json, os, requests, gspread
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive.file',
    'https://www.googleapis.com/auth/userinfo.email',
    'openid'
]

def check_login_status():
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
        if creds and creds.valid: return creds
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
                with open('token.json', 'w') as token: token.write(creds.to_json())
                return creds
            except: pass
    return None

def get_user_email(creds):
    try:
        response = requests.get('https://www.googleapis.com/oauth2/v1/userinfo?alt=json', headers={'Authorization': f'Bearer {creds.token}'})
        return response.json().get('email', 'Vendedor')
    except: return 'Vendedor'

def calcular_fecha_proximo_pago(fecha_inicio, dia_cobro):
    año = fecha_inicio.year; mes = fecha_inicio.month
    def get_safe_date(y, m, d):
        _, max_days = calendar.monthrange(y, m)
        return datetime.date(y, m, min(d, max_days))
    siguiente_cobro = get_safe_date(año, mes, dia_cobro)
    if siguiente_cobro <= fecha_inicio:
        mes += 1
        if mes > 12: mes = 1; año += 1
        siguiente_cobro = get_safe_date(año, mes, dia_cobro)
    return siguiente_cobro

def calcular_estado(fecha_vencimiento):
    hoy = datetime.date.today()
    if not fecha_vencimiento or str(fecha_vencimiento).strip() == "": return "Desconocido"
    if isinstance(fecha_vencimiento, str):
        try: fecha_vencimiento = datetime.datetime.strptime(fecha_vencimiento.split(" ")[0], "%Y-%m-%d").date()
        except: return "Desconocido"
    elif isinstance(fecha_vencimiento, datetime.datetime): fecha_vencimiento = fecha_vencimiento.date()
    dias_restantes = (fecha_vencimiento - hoy).days
    if dias_restantes > 5: return "Activo"
    elif 4 <= dias_restantes <= 5: return "Próximo a vencer"
    elif 2 <= dias_restantes <= 3: return "Recordatorio de pago"
    else: return "Vencido"

class DatabaseMobile:
    def __init__(self, creds, page):
        self.creds = creds
        self.gc = gspread.authorize(self.creds)
        self.email = get_user_email(self.creds)
        self.spreadsheet_name = "GestorSuscripciones_Central"
        self.page = page
        self.sh = self.gc.open(self.spreadsheet_name)

    def get_table(self, sheet_name):
        try:
            ws = self.sh.worksheet(sheet_name)
            data = ws.get_all_records()
            return data
        except Exception as e:
            self.show_error(f"Error cargando {sheet_name}: {e}")
            return []

    def save_table(self, sheet_name, data_list):
        try:
            ws = self.sh.worksheet(sheet_name)
            ws.clear()
            if not data_list: return True
            headers = list(data_list[0].keys())
            values = [headers]
            for row in data_list:
                values.append([row.get(h, "") for h in headers])
            ws.update(range_name='A1', values=values)
            return True
        except Exception as e:
            self.show_error(f"Error guardando {sheet_name}: {e}")
            return False
            
    def get_new_id(self, sheet_name):
        data = self.get_table(sheet_name)
        if not data: return 1
        max_id = 0
        for r in data:
            try:
                vid = int(r.get("ID", 0))
                if vid > max_id: max_id = vid
            except: pass
        return max_id + 1

    def show_error(self, msg):
        self.page.snack_bar = ft.SnackBar(ft.Text(msg), bgcolor=ft.colors.ERROR)
        self.page.snack_bar.open = True
        self.page.update()

def main(page: ft.Page):
    page.title = "Gestor Suscripciones Móvil"
    page.theme_mode = ft.ThemeMode.DARK
    page.window_width = 400
    page.window_height = 800
    
    db = None
    
    def on_login_click(e):
        nonlocal db
        page.snack_bar = ft.SnackBar(ft.Text("⚠️ En móviles no se puede abrir el navegador. Genera token.json en tu PC y mételo en el ZIP antes de compilar.", color="white"), bgcolor="red")
        page.snack_bar.open = True
        page.update()

    def build_main_ui():
        page.controls.clear()
        
        main_container = ft.Container(expand=True)
        
        def show_dashboard(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Dashboard...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_serv = db.get_table("Servicios")
            df_cli = db.get_table("Clientes")
            df_plan = db.get_table("Plantillas")
            
            plantilla_row = next((r for r in df_plan if r.get('Activa') == 'Sí'), None)
            plantilla = plantilla_row['Texto'] if plantilla_row else "Hola {NOMBRE_CLIENTE}, paga tus ${MONTO} de {SERVICIO}."
            
            items = []
            for r in df_serv:
                estado = calcular_estado(r.get('Fecha_Proximo_Pago', ''))
                if estado in ["Vencido", "Recordatorio de pago", "Próximo a vencer"]:
                    cli = next((c for c in df_cli if str(c.get('ID', '')) == str(r.get('Cliente_ID', ''))), None)
                    if cli:
                        tel = str(cli.get('Telefono', '')); nom = cli.get('Nombre', 'Cliente')
                        if not tel.startswith('+'): tel = '+57' + tel
                        monto = r.get('Precio_Mensual', 0)
                        
                        msg = plantilla.replace("{NOMBRE_CLIENTE}", nom).replace("{SERVICIO}", str(r.get('Servicio_Nombre', ''))).replace("{FECHA_VENCIMIENTO}", str(r.get('Fecha_Proximo_Pago', ''))).replace("{MONTO}", str(monto)).replace("{PLATAFORMAS}", str(r.get('Plataformas_Incluidas', '')))
                        url = f"https://wa.me/{tel.replace('+','')}?text={urllib.parse.quote(msg)}"
                        
                        color = ft.colors.RED if estado == "Vencido" else ft.colors.ORANGE
                        items.append(
                            ft.Card(
                                content=ft.Container(
                                    padding=10,
                                    content=ft.Column([
                                        ft.Text(f"{nom} - {r.get('Servicio_Nombre', '')}", weight=ft.FontWeight.BOLD, size=16),
                                        ft.Text(f"Estado: {estado} | Fecha: {r.get('Fecha_Proximo_Pago', '')} | Monto: ${monto}", color=color),
                                        ft.ElevatedButton("Cobrar por WhatsApp", icon=ft.icons.MESSAGE, bgcolor=ft.colors.GREEN, color=ft.colors.WHITE, on_click=lambda e, u=url: webbrowser.open(u))
                                    ])
                                )
                            )
                        )
            
            main_container.content = ft.ListView(controls=[ft.Text("Cobros Pendientes", size=24, weight=ft.FontWeight.BOLD)] + items, expand=True, spacing=10)
            page.drawer.open = False
            page.update()
            
        def show_clientes(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Clientes...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_cli = db.get_table("Clientes")
            items = []
            
            def edit_cliente(c_data):
                def save_edit(e):
                    for row in df_cli:
                        if str(row.get('ID')) == str(c_data.get('ID')):
                            row['Nombre'] = t_nom.value
                            row['Telefono'] = t_tel.value
                            row['Correo'] = t_cor.value
                    db.save_table("Clientes", df_cli)
                    bs.open = False; page.update(); show_clientes()
                
                t_nom = ft.TextField(label="Nombre", value=c_data.get('Nombre', ''))
                t_tel = ft.TextField(label="Teléfono", value=str(c_data.get('Telefono', '')))
                t_cor = ft.TextField(label="Correo", value=c_data.get('Correo', ''))
                
                bs = ft.BottomSheet(
                    ft.Container(
                        padding=20,
                        content=ft.Column([
                            ft.Text("Editar Cliente", size=20, weight=ft.FontWeight.BOLD),
                            t_nom, t_tel, t_cor,
                            ft.ElevatedButton("Guardar", on_click=save_edit)
                        ], tight=True)
                    )
                )
                page.overlay.append(bs)
                bs.open = True
                page.update()

            for r in df_cli:
                items.append(
                    ft.ListTile(
                        leading=ft.Icon(ft.icons.PERSON),
                        title=ft.Text(r.get('Nombre', ''), weight=ft.FontWeight.BOLD),
                        subtitle=ft.Text(f"{r.get('Telefono', '')} | {r.get('Estado', '')}"),
                        trailing=ft.IconButton(ft.icons.EDIT, on_click=lambda e, data=r: edit_cliente(data))
                    )
                )
                
            def add_cliente(e):
                def save_new(ev):
                    new_id = db.get_new_id("Clientes")
                    new_row = {"ID": new_id, "Vendedor": db.email, "Nombre": t_nom.value, "Telefono": t_tel.value, "Correo": t_cor.value, "Estado": "Activo"}
                    df_cli.append(new_row)
                    db.save_table("Clientes", df_cli)
                    bs.open = False; page.update(); show_clientes()
                    
                t_nom = ft.TextField(label="Nombre")
                t_tel = ft.TextField(label="Teléfono")
                t_cor = ft.TextField(label="Correo")
                bs = ft.BottomSheet(
                    ft.Container(
                        padding=20,
                        content=ft.Column([
                            ft.Text("Nuevo Cliente", size=20, weight=ft.FontWeight.BOLD),
                            t_nom, t_tel, t_cor,
                            ft.ElevatedButton("Guardar", on_click=save_new)
                        ], tight=True)
                    )
                )
                page.overlay.append(bs); bs.open = True; page.update()

            main_container.content = ft.Column([
                ft.Row([
                    ft.Text("Mis Clientes", size=24, weight=ft.FontWeight.BOLD),
                    ft.IconButton(ft.icons.ADD_CIRCLE, icon_color=ft.colors.GREEN, icon_size=30, on_click=add_cliente)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.ListView(controls=items, expand=True)
            ], expand=True)
            
            page.drawer.open = False
            page.update()

        def show_cuentas(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Cuentas...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_cuentas = db.get_table("Cuentas_Completas")
            df_perf = db.get_table("Perfiles")
            items = []
            
            for r in df_cuentas:
                cuenta_id = str(r.get('ID', ''))
                perfiles_cuenta = [p for p in df_perf if str(p.get('Cuenta_ID', '')) == cuenta_id]
                items.append(
                    ft.Card(
                        content=ft.Container(
                            padding=10,
                            content=ft.Column([
                                ft.Text(f"{r.get('Plataforma', '')} - {r.get('Correo', '')}", weight=ft.FontWeight.BOLD, size=16),
                                ft.Text(f"Clave: {r.get('Clave', '')} | Renovación: {r.get('Dia_Renovacion', '')} | Estado: {r.get('Estado', '')}"),
                                ft.Text(f"Perfiles Ocupados: {len(perfiles_cuenta)} / {r.get('Capacidad_Maxima', '')}"),
                                ft.ElevatedButton("Notificar Cambio Datos", icon=ft.icons.NOTIFICATION_IMPORTANT, bgcolor=ft.colors.ORANGE, color=ft.colors.WHITE, on_click=lambda e: page.snack_bar.open_snack_bar("La notificación masiva funciona mejor en PC por las ventanas emergentes."))
                            ])
                        )
                    )
                )
                
            main_container.content = ft.Column([
                ft.Text("Inventario de Cuentas", size=24, weight=ft.FontWeight.BOLD),
                ft.ListView(controls=items, expand=True)
            ], expand=True)
            
            page.drawer.open = False
            page.update()

        def show_metricas(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Métricas...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_serv = db.get_table("Servicios")
            df_cuentas = db.get_table("Cuentas_Completas")
            df_perf = db.get_table("Perfiles")
            
            mrr_15 = 0; mrr_30 = 0; fuga = 0
            activos = 0
            if df_serv:
                for r in df_serv:
                    estado = calcular_estado(r.get('Fecha_Proximo_Pago', ''))
                    try: precio = float(r.get('Precio_Mensual', 0))
                    except: precio = 0
                    if estado in ["Activo", "Próximo a vencer", "Recordatorio de pago"]:
                        activos += 1
                        try: dia = int(r.get('Dia_Cobro', 0))
                        except: dia = 0
                        if dia == 15: mrr_15 += precio
                        elif dia == 30: mrr_30 += precio
                    elif estado == "Vencido": fuga += precio
                        
            costos = 0; cap_total = 0
            if df_cuentas:
                activas = [c for c in df_cuentas if c.get('Estado') == 'Activa']
                for r in activas:
                    try: c = float(r.get('Costo_Mensual', 0))
                    except: c = 0
                    costos += c
                    try: cap = int(r.get('Capacidad_Maxima', 0))
                    except: cap = 0
                    cap_total += cap
                
            ganancia = (mrr_15 + mrr_30) - costos
            ocupacion = len(df_perf) if df_perf else 0
            porc_oc = (ocupacion / cap_total * 100) if cap_total > 0 else 0
            arpu = ((mrr_15 + mrr_30) / activos) if activos > 0 else 0
            
            main_container.content = ft.Column([
                ft.Text("Métricas y Finanzas", size=24, weight=ft.FontWeight.BOLD),
                ft.Row([ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("MRR 15", size=12), ft.Text(f"${mrr_15:,.0f}", size=20, color=ft.colors.GREEN)]))), ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("MRR 30", size=12), ft.Text(f"${mrr_30:,.0f}", size=20, color=ft.colors.GREEN)])))]),
                ft.Row([ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Costos Fijos", size=12), ft.Text(f"${costos:,.0f}", size=20, color=ft.colors.RED)]))), ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Ganancia Neta", size=12), ft.Text(f"${ganancia:,.0f}", size=20, color=ft.colors.BLUE)])))]),
                ft.Row([ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Ocupación", size=12), ft.Text(f"{porc_oc:.1f}%", size=20, color=ft.colors.ORANGE)]))), ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Ticket (ARPU)", size=12), ft.Text(f"${arpu:,.0f}", size=20, color=ft.colors.PURPLE)])))]),
                ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Fuga (Vencidos)", size=12), ft.Text(f"${fuga:,.0f}", size=20, color=ft.colors.RED)])))
            ], scroll=ft.ScrollMode.AUTO, expand=True)
            page.drawer.open = False
            page.update()

        def show_combos(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Combos...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            df_combos = db.get_table("Combos")
            items = []
            for r in df_combos:
                items.append(
                    ft.ListTile(
                        leading=ft.Icon(ft.icons.LOCAL_OFFER),
                        title=ft.Text(f"{r.get('Nombre', '')} (${r.get('Precio_Mensual', '')})", weight=ft.FontWeight.BOLD),
                        subtitle=ft.Text(f"Incluye: {r.get('Plataformas', '')} | Activo: {r.get('Activo', '')}"),
                        trailing=ft.IconButton(ft.icons.EDIT, on_click=lambda e: page.snack_bar.open_snack_bar("Edición de combos desde PC recomendada"))
                    )
                )
            main_container.content = ft.Column([ft.Text("Catálogo de Combos", size=24, weight=ft.FontWeight.BOLD), ft.ListView(controls=items, expand=True)], expand=True)
            page.drawer.open = False
            page.update()
            
        def show_plantillas(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Plantillas...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            df_plan = db.get_table("Plantillas")
            items = []
            for r in df_plan:
                items.append(
                    ft.Card(content=ft.Container(padding=10, content=ft.Column([
                        ft.Text(f"{r.get('Nombre', '')} (Activa: {r.get('Activa', '')})", weight=ft.FontWeight.BOLD),
                        ft.Text(r.get('Texto', ''), size=12, italic=True)
                    ])))
                )
            main_container.content = ft.Column([ft.Text("Plantillas WhatsApp", size=24, weight=ft.FontWeight.BOLD), ft.ListView(controls=items, expand=True)], expand=True)
            page.drawer.open = False
            page.update()

        page.drawer = ft.NavigationDrawer(
            controls=[
                ft.Container(height=12),
                ft.Text("Menú Principal", size=20, weight=ft.FontWeight.BOLD),
                ft.Divider(thickness=2),
                ft.ListTile(leading=ft.Icon(ft.icons.DASHBOARD), title=ft.Text("Dashboard"), on_click=show_dashboard),
                ft.ListTile(leading=ft.Icon(ft.icons.PEOPLE), title=ft.Text("Mis Clientes"), on_click=show_clientes),
                ft.ListTile(leading=ft.Icon(ft.icons.TV), title=ft.Text("Inventario Cuentas"), on_click=show_cuentas),
                ft.ListTile(leading=ft.Icon(ft.icons.LOCAL_OFFER), title=ft.Text("Combos"), on_click=show_combos),
                ft.ListTile(leading=ft.Icon(ft.icons.MESSAGE), title=ft.Text("Plantillas"), on_click=show_plantillas),
                ft.ListTile(leading=ft.Icon(ft.icons.ANALYTICS), title=ft.Text("Métricas"), on_click=show_metricas),
            ],
        )
        
        def show_msg(msg):
            page.snack_bar = ft.SnackBar(ft.Text(msg)); page.snack_bar.open = True; page.update()
            
        page.appbar = ft.AppBar(
            leading=ft.IconButton(ft.icons.MENU, on_click=lambda e: page.show_drawer(page.drawer)),
            title=ft.Text("Gestor Móvil"),
            bgcolor=ft.colors.SURFACE_VARIANT,
            actions=[ft.IconButton(ft.icons.REFRESH, on_click=show_dashboard)]
        )
        
        page.add(main_container)
        show_dashboard()

    creds = check_login_status()
    if creds:
        db = DatabaseMobile(creds, page)
        build_main_ui()
    else:
        page.add(
            ft.Column([
                ft.Text("Gestor Móvil", size=30, weight=ft.FontWeight.BOLD),
                ft.ElevatedButton("Iniciar Sesión con Google", on_click=on_login_click)
            ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        )

if __name__ == "__main__":
    ft.app(target=main)
