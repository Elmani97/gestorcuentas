import flet as ft
import pandas as pd
import datetime, calendar, urllib.parse, webbrowser, json, os, requests, gspread
from google_auth_oauthlib.flow import InstalledAppFlow
from google.auth.transport.requests import Request
from google.oauth2.credentials import Credentials

SCOPES = [
    'https://www.googleapis.com/auth/spreadsheets',
    'https://www.googleapis.com/auth/drive.file',
    'https://www.googleapis.com/auth/userinfo.email',
    'openid'
]

def check_login_status():
    if os.path.exists('token.json'):
        creds = Credentials.from_authorized_user_file('token.json', SCOPES)
        if creds and creds.valid: return creds
        if creds and creds.expired and creds.refresh_token:
            try:
                creds.refresh(Request())
                with open('token.json', 'w') as token: token.write(creds.to_json())
                return creds
            except: pass
    return None

def get_user_email(creds):
    try:
        response = requests.get('https://www.googleapis.com/oauth2/v1/userinfo?alt=json', headers={'Authorization': f'Bearer {creds.token}'})
        return response.json().get('email', 'Vendedor')
    except: return 'Vendedor'

def calcular_fecha_proximo_pago(fecha_inicio, dia_cobro):
    año = fecha_inicio.year; mes = fecha_inicio.month
    def get_safe_date(y, m, d):
        _, max_days = calendar.monthrange(y, m)
        return datetime.date(y, m, min(d, max_days))
    siguiente_cobro = get_safe_date(año, mes, dia_cobro)
    if siguiente_cobro <= fecha_inicio:
        mes += 1
        if mes > 12: mes = 1; año += 1
        siguiente_cobro = get_safe_date(año, mes, dia_cobro)
    return siguiente_cobro

def calcular_estado(fecha_vencimiento):
    hoy = datetime.date.today()
    if pd.isna(fecha_vencimiento): return "Desconocido"
    if isinstance(fecha_vencimiento, str):
        try: fecha_vencimiento = datetime.datetime.strptime(fecha_vencimiento.split(" ")[0], "%Y-%m-%d").date()
        except: return "Desconocido"
    elif isinstance(fecha_vencimiento, datetime.datetime): fecha_vencimiento = fecha_vencimiento.date()
    dias_restantes = (fecha_vencimiento - hoy).days
    if dias_restantes > 5: return "Activo"
    elif 4 <= dias_restantes <= 5: return "Próximo a vencer"
    elif 2 <= dias_restantes <= 3: return "Recordatorio de pago"
    else: return "Vencido"

class DatabaseMobile:
    def __init__(self, creds, page):
        self.creds = creds
        self.gc = gspread.authorize(self.creds)
        self.email = get_user_email(self.creds)
        self.spreadsheet_name = "GestorSuscripciones_Central"
        self.page = page
        self.sh = self.gc.open(self.spreadsheet_name)

    def get_table(self, sheet_name):
        try:
            ws = self.sh.worksheet(sheet_name)
            data = ws.get_all_values()
            if not data or len(data) == 1: return pd.DataFrame(columns=data[0] if data else [])
            headers = data.pop(0)
            df = pd.DataFrame(data, columns=headers)
            numeric_cols = ["ID", "Precio_Individual", "Costo_Mensual", "Capacidad_Base", "Capacidad_Maxima", "Precio_Mensual", "Precio_Total", "Periodo_Meses", "Dia_Cobro", "Cuenta_ID", "Cliente_ID", "Servicio_ID"]
            for col in numeric_cols:
                if col in df.columns: df[col] = pd.to_numeric(df[col], errors='coerce')
            return df
        except Exception as e:
            self.show_error(f"Error cargando {sheet_name}: {e}")
            return pd.DataFrame()

    def save_table(self, sheet_name, df):
        try:
            ws = self.sh.worksheet(sheet_name)
            ws.clear()
            df_clean = df.fillna("")
            ws.update(range_name='A1', values=[df_clean.columns.values.tolist()] + df_clean.values.tolist())
            return True
        except Exception as e:
            self.show_error(f"Error guardando {sheet_name}: {e}")
            return False
            
    def get_new_id(self, sheet_name):
        df = self.get_table(sheet_name)
        if df.empty or "ID" not in df.columns: return 1
        return int(df["ID"].max()) + 1 if pd.notna(df["ID"].max()) else 1

    def show_error(self, msg):
        self.page.snack_bar = ft.SnackBar(ft.Text(msg), bgcolor=ft.colors.ERROR)
        self.page.snack_bar.open = True
        self.page.update()

def main(page: ft.Page):
    page.title = "Gestor Suscripciones Móvil"
    page.theme_mode = ft.ThemeMode.DARK
    page.window_width = 400
    page.window_height = 800
    
    db = None
    
    def on_login_click(e):
        nonlocal db
        try:
            flow = InstalledAppFlow.from_client_secrets_file('credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)
            with open('token.json', 'w') as token: token.write(creds.to_json())
            db = DatabaseMobile(creds, page)
            build_main_ui()
        except Exception as ex:
            page.snack_bar = ft.SnackBar(ft.Text(f"Fallo login: {ex}")); page.snack_bar.open = True; page.update()

    def build_main_ui():
        page.controls.clear()
        
        main_container = ft.Container(expand=True)
        
        def show_dashboard(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Dashboard...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_serv = db.get_table("Servicios")
            df_cli = db.get_table("Clientes")
            df_plan = db.get_table("Plantillas")
            plantilla = df_plan[df_plan['Activa'] == 'Sí'].iloc[0]['Texto'] if not df_plan.empty else "Hola {NOMBRE_CLIENTE}, paga tus ${MONTO} de {SERVICIO}."
            
            items = []
            for _, r in df_serv.iterrows():
                estado = calcular_estado(r['Fecha_Proximo_Pago'])
                if estado in ["Vencido", "Recordatorio de pago", "Próximo a vencer"]:
                    cli = df_cli[df_cli['ID'].astype(str) == str(r['Cliente_ID'])]
                    if not cli.empty:
                        c_data = cli.iloc[0]
                        tel = str(c_data['Telefono']); nom = c_data['Nombre']
                        if not tel.startswith('+'): tel = '+57' + tel
                        monto = r.get('Precio_Mensual', 0)
                        
                        msg = plantilla.replace("{NOMBRE_CLIENTE}", nom).replace("{SERVICIO}", str(r.get('Servicio_Nombre', ''))).replace("{FECHA_VENCIMIENTO}", str(r['Fecha_Proximo_Pago'])).replace("{MONTO}", str(monto)).replace("{PLATAFORMAS}", str(r.get('Plataformas_Incluidas', '')))
                        url = f"https://wa.me/{tel.replace('+','')}?text={urllib.parse.quote(msg)}"
                        
                        color = ft.colors.RED if estado == "Vencido" else ft.colors.ORANGE
                        items.append(
                            ft.Card(
                                content=ft.Container(
                                    padding=10,
                                    content=ft.Column([
                                        ft.Text(f"{nom} - {r.get('Servicio_Nombre', '')}", weight=ft.FontWeight.BOLD, size=16),
                                        ft.Text(f"Estado: {estado} | Fecha: {r['Fecha_Proximo_Pago']} | Monto: ${monto}", color=color),
                                        ft.ElevatedButton("Cobrar por WhatsApp", icon=ft.icons.MESSAGE, bgcolor=ft.colors.GREEN, color=ft.colors.WHITE, on_click=lambda e, u=url: webbrowser.open(u))
                                    ])
                                )
                            )
                        )
            
            main_container.content = ft.ListView(controls=[ft.Text("Cobros Pendientes", size=24, weight=ft.FontWeight.BOLD)] + items, expand=True, spacing=10)
            page.drawer.open = False
            page.update()
            
        def show_clientes(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Clientes...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_cli = db.get_table("Clientes")
            items = []
            
            def edit_cliente(c_data):
                def save_edit(e):
                    idx = df_cli.index[df_cli['ID'].astype(str) == str(c_data['ID'])].tolist()[0]
                    df_cli.at[idx, 'Nombre'] = t_nom.value
                    df_cli.at[idx, 'Telefono'] = t_tel.value
                    df_cli.at[idx, 'Correo'] = t_cor.value
                    db.save_table("Clientes", df_cli)
                    bs.open = False; page.update(); show_clientes()
                
                t_nom = ft.TextField(label="Nombre", value=c_data['Nombre'])
                t_tel = ft.TextField(label="Teléfono", value=c_data['Telefono'])
                t_cor = ft.TextField(label="Correo", value=c_data['Correo'])
                
                bs = ft.BottomSheet(
                    ft.Container(
                        padding=20,
                        content=ft.Column([
                            ft.Text("Editar Cliente", size=20, weight=ft.FontWeight.BOLD),
                            t_nom, t_tel, t_cor,
                            ft.ElevatedButton("Guardar", on_click=save_edit)
                        ], tight=True)
                    )
                )
                page.overlay.append(bs)
                bs.open = True
                page.update()

            for _, r in df_cli.iterrows():
                items.append(
                    ft.ListTile(
                        leading=ft.Icon(ft.icons.PERSON),
                        title=ft.Text(r['Nombre'], weight=ft.FontWeight.BOLD),
                        subtitle=ft.Text(f"{r['Telefono']} | {r['Estado']}"),
                        trailing=ft.IconButton(ft.icons.EDIT, on_click=lambda e, data=r: edit_cliente(data))
                    )
                )
                
            def add_cliente(e):
                def save_new(ev):
                    new_id = db.get_new_id("Clientes")
                    new_row = {"ID": new_id, "Vendedor": db.email, "Nombre": t_nom.value, "Telefono": t_tel.value, "Correo": t_cor.value, "Estado": "Activo"}
                    new_df = pd.concat([df_cli, pd.DataFrame([new_row])], ignore_index=True)
                    db.save_table("Clientes", new_df)
                    bs.open = False; page.update(); show_clientes()
                    
                t_nom = ft.TextField(label="Nombre")
                t_tel = ft.TextField(label="Teléfono")
                t_cor = ft.TextField(label="Correo")
                bs = ft.BottomSheet(
                    ft.Container(
                        padding=20,
                        content=ft.Column([
                            ft.Text("Nuevo Cliente", size=20, weight=ft.FontWeight.BOLD),
                            t_nom, t_tel, t_cor,
                            ft.ElevatedButton("Guardar", on_click=save_new)
                        ], tight=True)
                    )
                )
                page.overlay.append(bs); bs.open = True; page.update()

            main_container.content = ft.Column([
                ft.Row([
                    ft.Text("Mis Clientes", size=24, weight=ft.FontWeight.BOLD),
                    ft.IconButton(ft.icons.ADD_CIRCLE, icon_color=ft.colors.GREEN, icon_size=30, on_click=add_cliente)
                ], alignment=ft.MainAxisAlignment.SPACE_BETWEEN),
                ft.ListView(controls=items, expand=True)
            ], expand=True)
            
            page.drawer.open = False
            page.update()

        def show_cuentas(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Cuentas...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_cuentas = db.get_table("Cuentas_Completas")
            df_perf = db.get_table("Perfiles")
            items = []
            
            for _, r in df_cuentas.iterrows():
                cuenta_id = str(r['ID'])
                perfiles_cuenta = df_perf[df_perf['Cuenta_ID'].astype(str) == cuenta_id]
                items.append(
                    ft.Card(
                        content=ft.Container(
                            padding=10,
                            content=ft.Column([
                                ft.Text(f"{r['Plataforma']} - {r['Correo']}", weight=ft.FontWeight.BOLD, size=16),
                                ft.Text(f"Clave: {r['Clave']} | Renovación: {r['Dia_Renovacion']} | Estado: {r['Estado']}"),
                                ft.Text(f"Perfiles Ocupados: {len(perfiles_cuenta)} / {r['Capacidad_Maxima']}"),
                                ft.ElevatedButton("Notificar Cambio Datos", icon=ft.icons.NOTIFICATION_IMPORTANT, bgcolor=ft.colors.ORANGE, color=ft.colors.WHITE, on_click=lambda e: page.snack_bar.open_snack_bar("La notificación masiva funciona mejor en PC por las ventanas emergentes."))
                            ])
                        )
                    )
                )
                
            main_container.content = ft.Column([
                ft.Text("Inventario de Cuentas", size=24, weight=ft.FontWeight.BOLD),
                ft.ListView(controls=items, expand=True)
            ], expand=True)
            
            page.drawer.open = False
            page.update()

        def show_metricas(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Métricas...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            
            df_serv = db.get_table("Servicios")
            df_cuentas = db.get_table("Cuentas_Completas")
            df_perf = db.get_table("Perfiles")
            
            mrr_15 = 0; mrr_30 = 0; fuga = 0
            activos = 0
            if not df_serv.empty:
                for _, r in df_serv.iterrows():
                    estado = calcular_estado(r['Fecha_Proximo_Pago'])
                    try: precio = float(r.get('Precio_Mensual', 0))
                    except: precio = 0
                    if pd.isna(precio): precio = 0
                    if estado in ["Activo", "Próximo a vencer", "Recordatorio de pago"]:
                        activos += 1
                        if int(r.get('Dia_Cobro', 0)) == 15: mrr_15 += precio
                        elif int(r.get('Dia_Cobro', 0)) == 30: mrr_30 += precio
                    elif estado == "Vencido": fuga += precio
                        
            costos = 0; cap_total = 0
            if not df_cuentas.empty:
                activas = df_cuentas[df_cuentas['Estado'] == 'Activa']
                for _, r in activas.iterrows():
                    try: c = float(r.get('Costo_Mensual', 0))
                    except: c = 0
                    if pd.isna(c): c = 0
                    costos += c
                cap_total = activas['Capacidad_Maxima'].sum()
                
            ganancia = (mrr_15 + mrr_30) - costos
            ocupacion = len(df_perf) if not df_perf.empty else 0
            porc_oc = (ocupacion / cap_total * 100) if cap_total > 0 else 0
            arpu = ((mrr_15 + mrr_30) / activos) if activos > 0 else 0
            
            main_container.content = ft.Column([
                ft.Text("Métricas y Finanzas", size=24, weight=ft.FontWeight.BOLD),
                ft.Row([ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("MRR 15", size=12), ft.Text(f"${mrr_15:,.0f}", size=20, color=ft.colors.GREEN)]))), ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("MRR 30", size=12), ft.Text(f"${mrr_30:,.0f}", size=20, color=ft.colors.GREEN)])))]),
                ft.Row([ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Costos Fijos", size=12), ft.Text(f"${costos:,.0f}", size=20, color=ft.colors.RED)]))), ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Ganancia Neta", size=12), ft.Text(f"${ganancia:,.0f}", size=20, color=ft.colors.BLUE)])))]),
                ft.Row([ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Ocupación", size=12), ft.Text(f"{porc_oc:.1f}%", size=20, color=ft.colors.ORANGE)]))), ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Ticket (ARPU)", size=12), ft.Text(f"${arpu:,.0f}", size=20, color=ft.colors.PURPLE)])))]),
                ft.Card(content=ft.Container(padding=15, content=ft.Column([ft.Text("Fuga (Vencidos)", size=12), ft.Text(f"${fuga:,.0f}", size=20, color=ft.colors.RED)])))
            ], scroll=ft.ScrollMode.AUTO, expand=True)
            page.drawer.open = False
            page.update()

        def show_combos(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Combos...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            df_combos = db.get_table("Combos")
            items = []
            for _, r in df_combos.iterrows():
                items.append(
                    ft.ListTile(
                        leading=ft.Icon(ft.icons.LOCAL_OFFER),
                        title=ft.Text(f"{r['Nombre']} (${r['Precio_Mensual']})", weight=ft.FontWeight.BOLD),
                        subtitle=ft.Text(f"Incluye: {r['Plataformas']} | Activo: {r['Activo']}"),
                        trailing=ft.IconButton(ft.icons.EDIT, on_click=lambda e: page.snack_bar.open_snack_bar("Edición de combos desde PC recomendada"))
                    )
                )
            main_container.content = ft.Column([ft.Text("Catálogo de Combos", size=24, weight=ft.FontWeight.BOLD), ft.ListView(controls=items, expand=True)], expand=True)
            page.drawer.open = False
            page.update()
            
        def show_plantillas(e=None):
            main_container.content = ft.Column([ft.Text("Cargando Plantillas...", size=20)], alignment=ft.MainAxisAlignment.CENTER)
            page.update()
            df_plan = db.get_table("Plantillas")
            items = []
            for _, r in df_plan.iterrows():
                items.append(
                    ft.Card(content=ft.Container(padding=10, content=ft.Column([
                        ft.Text(f"{r['Nombre']} (Activa: {r['Activa']})", weight=ft.FontWeight.BOLD),
                        ft.Text(r['Texto'], size=12, italic=True)
                    ])))
                )
            main_container.content = ft.Column([ft.Text("Plantillas WhatsApp", size=24, weight=ft.FontWeight.BOLD), ft.ListView(controls=items, expand=True)], expand=True)
            page.drawer.open = False
            page.update()

        page.drawer = ft.NavigationDrawer(
            controls=[
                ft.Container(height=12),
                ft.Text("Menú Principal", size=20, weight=ft.FontWeight.BOLD),
                ft.Divider(thickness=2),
                ft.ListTile(leading=ft.Icon(ft.icons.DASHBOARD), title=ft.Text("Dashboard"), on_click=show_dashboard),
                ft.ListTile(leading=ft.Icon(ft.icons.PEOPLE), title=ft.Text("Mis Clientes"), on_click=show_clientes),
                ft.ListTile(leading=ft.Icon(ft.icons.TV), title=ft.Text("Inventario Cuentas"), on_click=show_cuentas),
                ft.ListTile(leading=ft.Icon(ft.icons.LOCAL_OFFER), title=ft.Text("Combos"), on_click=show_combos),
                ft.ListTile(leading=ft.Icon(ft.icons.MESSAGE), title=ft.Text("Plantillas"), on_click=show_plantillas),
                ft.ListTile(leading=ft.Icon(ft.icons.ANALYTICS), title=ft.Text("Métricas"), on_click=show_metricas),
            ],
        )
        
        def show_msg(msg):
            page.snack_bar = ft.SnackBar(ft.Text(msg)); page.snack_bar.open = True; page.update()
            
        page.appbar = ft.AppBar(
            leading=ft.IconButton(ft.icons.MENU, on_click=lambda e: page.show_drawer(page.drawer)),
            title=ft.Text("Gestor Móvil"),
            bgcolor=ft.colors.SURFACE_VARIANT,
            actions=[ft.IconButton(ft.icons.REFRESH, on_click=show_dashboard)]
        )
        
        page.add(main_container)
        show_dashboard()

    creds = check_login_status()
    if creds:
        db = DatabaseMobile(creds, page)
        build_main_ui()
    else:
        page.add(
            ft.Column([
                ft.Text("Gestor Móvil", size=30, weight=ft.FontWeight.BOLD),
                ft.ElevatedButton("Iniciar Sesión con Google", on_click=on_login_click)
            ], alignment=ft.MainAxisAlignment.CENTER, horizontal_alignment=ft.CrossAxisAlignment.CENTER)
        )

if __name__ == "__main__":
    ft.app(target=main)
