class WSGIRequestHandler: pass
